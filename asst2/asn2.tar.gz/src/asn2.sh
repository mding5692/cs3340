#!/bin/sh

arg1=$1
arg2=$2

java FindConnectedComp
